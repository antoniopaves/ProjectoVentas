<?php
Class Producto{
    public int $id_producto;
    public String $nombre;
    public String $empresa;
    public int $precio;
    public int $cantidad;
    public String $img;
}