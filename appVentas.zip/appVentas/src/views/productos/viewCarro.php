<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Carrito</title>
</head>
<body>
    <h1>Carrito de compras</h1>
    <p>Vista de carrito vacía.</p>
</body>
</html>